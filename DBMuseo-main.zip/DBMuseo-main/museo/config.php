<?php

$conn = mysqli_connect("localhost","root", "", "db_gestioneopere");
if(!$conn){
    die("Qualcosa non ha funzionato");
}
?>